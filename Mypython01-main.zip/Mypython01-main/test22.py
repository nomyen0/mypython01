# คำสั่ง while 
'''
while เงื่อนไข (True/False) :
    คำสั่ง 1
    คำสั่ง 2
'''

aa = 1

while aa <= 5 :
    print('1111')
    print('2222')
    aa = aa + 1 

print('bye bye...')