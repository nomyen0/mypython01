# สำหรับ Python สโคปการทำงานหนึ่งเราใช้ indent/ย่อหน้า/เยื้อง (กดปุ่ม Tab)

# คำสั่ง if

x = 200

if x <= 100 : #Colon อย่าลืม
    print('Hello....')
    print('Hi....')
    print('Hey....')

print('Bye bye....')
print('Ei ei...')