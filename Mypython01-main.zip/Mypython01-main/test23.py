# คำสั่ง for
'''
for var_name in range(n) :
    คำสั่ง(s)

for var_name in range(n, m) :
    คำสั่ง(s)

for var_name in range(n, m, o) :
    คำสั่ง(s)

for var_mane in STRING :
    คำสั่ง(s)
'''

# for aa in range(5) :
#   print(aa + 1, 'Hello')

#for aa in range(3, 7) :
#   print(aa, 'Hello')

#for aa in range(2, 10 , 3) :
#   print(aa, 'Hello')

for aa in 'Iot-SAU-xx' :
    print(aa, 'Hello')