
# ***** ตัวแปร variable คือ ชื่อที่ Dev ตั้งขึ้นมาเอง (ต้องเป็นไปตามกฎการตั้งชื่อ) เอาไว้เก็บข้อมูลที่เกิดชึ้นในฌปรแกรม
# ฟังก์ชันแปลงข้อความเป็นตัวเลข int(), float()

fullname = input('ป้อนชื่อ: ')
year_born = input('ป้อนปีเกิด พ.ศ.: ')
print('-----------------')
print(f'สวัสดีคุณ {fullname}')
print(f'คุณเกิดในปี {year_born} ตอนนี้คุณอายุ {2568 - int(year_born)}')
print('--------------')
# ใช้ , 
print('สวัสดีคุณ',fullname)
print('คุณเกิดในปี', year_born, 'ตอนนี้คุณอายุ',2568 - int(year_born))
print("--------------")
# ใช้ +
print('สวัสดีคุณ ' + fullname)
print('คุณเกิดในปี ' + str(year_born) + ' ตอนนี้คุณอายุ ' + str(2568 - int(year_born)))
print('-------------------')
#ใช้ format
print('สวัสดีคุณ {}'.format(fullname))
print('คุณเกิดในปี {} ตอนนี้คุณอายุ {}'.format(year_born, 2568 - int(year_born)))
print('-------------------')