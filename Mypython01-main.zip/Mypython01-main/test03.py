# คำสั่งแสดงผลข้อมูลใดๆ ทั้งหน้าจอ ใช้ฟังชัน print()
# string
print('Hel"lo')
print("H'i")
print("""Huuuu""")

# number
print(123456)         # integer/int
print(100.5)          # float

# boolean ตรรกะ มีแค่ True(จริง) และ False(เท็จ)
print(True)
print(False)

# Expression นิพจน์ คือ อะไรก็ตามที่มี process การทำงาน เช่น การคำนวณ ,ตัวแปร ,...
print(10+20+30)
print(5 * 2 / 4)
print("""asdf""")
print('''jkl;''') 