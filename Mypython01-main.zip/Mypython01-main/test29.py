# 1. function: no parameter no return
# parameter = ตัวแปรทีประเภทหนึ่ง ที่ใช้ได้เฉพาะในฟังก์ชันนั้นๆ เท่านั้น เขียนอยู่ในวงเล็บหลังชื่อฟังก์ชัน
# return = คำสั่งที่บ่งบองถึงการจบการทำงานชองฟังก์ชัน และส่งค่าที่อยู่หลัง return กลับไปยังจุดที่เรียกใช้ฟังก์ชัน(ถ้ามี)

'''
def func_name( ) :
    คำสั่ง
    คำสั่ง
    ......
'''

print('Wee...')

def showHi():
    print('Hi...')

print('Wow...')

def showHey():
    print('Hey...')

print('Woo...')

showHi()
showHi()
showHey()
showHey()
