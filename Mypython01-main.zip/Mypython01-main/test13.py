# คำสั่ง if-else

x = 20 + 10

if x <= 100 : #Colon อย่าลืม
    print('Hello....')
    print('Hi....')
    print('Hey....')
else : #colon อย่าลืม
    print('Wow...')
    print('Woo...')
    print('Wee...')

print('Bye bye....')
print('Ei ei...')