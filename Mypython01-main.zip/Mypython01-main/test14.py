# if-elif-else

score = 78

if score >= 80 : #colon อย่าลืม
    print('Grade A')
elif score >= 70 : #colon อย่าลืม
    print('Grade B')
elif score >= 60 : #colon อย่าลืม
    print('Grade C')
elif score >= 50 : #colon อย่าลืม
    print('Grade D')
else : #colon อย่าลืม *** else สุดท้ายจะเป็น elif ก็ได้
    print('Grade F')

print('Bye bye...')
print('ei ei...')